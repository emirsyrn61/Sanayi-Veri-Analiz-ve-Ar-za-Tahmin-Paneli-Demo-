
from flask import Flask, render_template, send_file, request, redirect, url_for
import pandas as pd, pickle, io, os
from report_generator import generate_pdf_report
import matplotlib.pyplot as plt

app = Flask(__name__)

MODEL_PATH = 'model.pkl'
DATA_PATH = 'data/sample_sensor_data.csv'

def ensure_model():
    if not os.path.exists(MODEL_PATH):
        return None
    with open(MODEL_PATH,'rb') as f:
        return pickle.load(f)

@app.route('/')
def index():
    model_data = ensure_model()
    df = pd.read_csv(DATA_PATH, parse_dates=['timestamp']).tail(24*60)  # last day
    # create small plot image
    fig, ax = plt.subplots(figsize=(8,3))
    sensors = [c for c in df.columns if c.startswith('sensor_')]
    for s in sensors:
        ax.plot(df['timestamp'], df[s], label=s)
    ax.legend(loc='upper right', fontsize='small')
    ax.set_title('Last 24 hours - sensor readings')
    ax.set_xticks([])
    imgpath = os.path.join('static','plot_lastday.png')
    os.makedirs('static', exist_ok=True)
    fig.savefig(imgpath, bbox_inches='tight')
    plt.close(fig)
    has_model = model_data is not None
    return render_template('index.html', has_model=has_model, imgpath=imgpath)

@app.route('/train')
def train():
    # convenience endpoint to run training script
    os.system('python train_model.py')
    return redirect(url_for('index'))

@app.route('/predict_now')
def predict_now():
    model_data = ensure_model()
    if model_data is None:
        return 'Model not trained. Visit /train first.'
    df = pd.read_csv(DATA_PATH, parse_dates=['timestamp'])
    feat_cols = model_data['features']
    # use last row
    last = df.iloc[-1:]
    for c in feat_cols:
        if c not in last.columns:
            # compute rolling features if missing
            base = c.replace('_rmean','').replace('_rstd','')
            if '_rmean' in c:
                last[c] = df[base].rolling(window=60, min_periods=1).mean().iloc[-1]
            if '_rstd' in c:
                last[c] = df[base].rolling(window=60, min_periods=1).std().fillna(0).iloc[-1]
    X = last[feat_cols].fillna(0)
    pred = model_data['model'].predict(X)[0]
    proba = model_data['model'].predict_proba(X)[0,1] if hasattr(model_data['model'],'predict_proba') else None
    return f'Prediction for latest timestamp: failure={int(pred)}, probability_of_failure={proba}'

@app.route('/report')
def report():
    generate_pdf_report(outpath='static/weekly_report.pdf', last_minutes=24*60)
    return send_file('static/weekly_report.pdf', as_attachment=True)

if __name__ == '__main__':
    app.run(debug=True)
