
import pandas as pd
import matplotlib.pyplot as plt

def generate_pdf_report(datafile='data/sample_sensor_data.csv', outpath='weekly_report.pdf', last_minutes=24*60):
    df = pd.read_csv(datafile, parse_dates=['timestamp'])
    df_recent = df.tail(last_minutes)
    plt.figure(figsize=(10,6))
    for c in [c for c in df.columns if c.startswith('sensor_')]:
        plt.plot(df_recent['timestamp'], df_recent[c], label=c)
    plt.legend()
    plt.xticks(rotation=30)
    plt.tight_layout()
    plt.savefig(outpath)
    plt.close()
    print('Saved', outpath)

if __name__ == '__main__':
    generate_pdf_report()
