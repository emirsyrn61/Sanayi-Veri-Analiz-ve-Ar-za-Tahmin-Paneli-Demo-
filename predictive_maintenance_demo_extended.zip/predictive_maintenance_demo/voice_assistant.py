import speech_recognition as sr
import pyttsx3
import requests

# Simple voice assistant for Sanayi Panel
# Commands:
# - 'rapor indir' -> downloads weekly report
# - 'durum tahmin' -> gets current failure prediction

BASE_URL = 'http://127.0.0.1:5000'

engine = pyttsx3.init()
r = sr.Recognizer()

def speak(text):
    engine.say(text)
    engine.runAndWait()

def listen_command():
    with sr.Microphone() as source:
        print("Dinliyorum...")
        audio = r.listen(source)
        try:
            cmd = r.recognize_google(audio, language='tr-TR')
            print("Komut:", cmd)
            return cmd.lower()
        except:
            speak("Anlamadım, tekrar edin.")
            return ""

if __name__ == '__main__':
    speak("Sanayi panel asistanı başlatıldı.")
    while True:
        cmd = listen_command()
        if 'çık' in cmd:
            speak("Kapatıyorum.")
            break
        elif 'rapor' in cmd:
            speak("Haftalık rapor indiriliyor.")
            r = requests.get(BASE_URL + '/report')
            open('weekly_report.pdf','wb').write(r.content)
            speak("Rapor kaydedildi.")
        elif 'durum' in cmd or 'tahmin' in cmd:
            resp = requests.get(BASE_URL + '/predict_now').text
            speak(resp)
        elif cmd.strip() == "":
            continue
        else:
            speak("Bu komutu bilmiyorum.")
