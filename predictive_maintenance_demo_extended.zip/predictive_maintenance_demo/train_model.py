
import pandas as pd
import numpy as np
import pickle
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import train_test_split
from sklearn.metrics import classification_report

df = pd.read_csv('data/sample_sensor_data.csv', parse_dates=['timestamp'])
# feature engineering: rolling mean/std for each sensor over last 60 minutes
for c in df.columns:
    if c.startswith('sensor_'):
        df[c + '_rmean'] = df[c].rolling(window=60, min_periods=1).mean()
        df[c + '_rstd'] = df[c].rolling(window=60, min_periods=1).std().fillna(0)
feat_cols = [c for c in df.columns if ('rmean' in c) or ('rstd' in c)]
X = df[feat_cols].fillna(0)
y = df['failure']
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42, stratify=y)
model = RandomForestClassifier(n_estimators=100, random_state=42)
model.fit(X_train, y_train)
y_pred = model.predict(X_test)
print(classification_report(y_test, y_pred))
with open('model.pkl', 'wb') as f:
    pickle.dump({'model': model, 'features': feat_cols}, f)
print('Saved model to model.pkl')
