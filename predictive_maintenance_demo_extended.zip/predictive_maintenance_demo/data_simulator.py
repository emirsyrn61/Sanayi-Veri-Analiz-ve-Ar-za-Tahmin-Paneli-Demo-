
import pandas as pd
import numpy as np
from datetime import datetime, timedelta

def generate_sample(sensor_count=4, minutes=24*60, start_time=None):
    if start_time is None:
        start_time = datetime.now() - timedelta(minutes=minutes)
    times = [start_time + timedelta(minutes=i) for i in range(minutes)]
    data = {'timestamp': times}
    np.random.seed(42)
    for s in range(sensor_count):
        base = 50 + 5*np.sin(np.linspace(0, 20, minutes)) + np.random.normal(0,1,minutes)
        # inject occasional spikes that represent anomalies
        spikes = np.random.choice([0,0,0,0,1], size=minutes, p=[0.95,0.01,0.01,0.02,0.01])
        spike_vals = spikes * np.random.uniform(15, 40, size=minutes)
        data[f'sensor_{s+1}'] = base + spike_vals + np.random.normal(0,0.8,minutes)
    df = pd.DataFrame(data)
    # create a 'failure' label when any sensor exceeds a threshold in the next hour (simulated)
    df['failure'] = 0
    threshold = 90
    for i in range(len(df)):
        window = df.loc[i:i+60, [c for c in df.columns if c.startswith('sensor_')]].max().max() if i+60 < len(df) else 0
        if window > threshold:
            df.at[i, 'failure'] = 1
    return df

if __name__ == '__main__':
    df = generate_sample(minutes=24*4)  # 4 days sample for demo
    df.to_csv('data/sample_sensor_data.csv', index=False)
    print('Sample data created at data/sample_sensor_data.csv')
